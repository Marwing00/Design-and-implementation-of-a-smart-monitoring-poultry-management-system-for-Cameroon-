<?php
    // Include necessary files and classes here
    include 'includes/database.php';
    include 'includes/loginServer.php';
    session_start();
    
    // Instantiate the LoginServer class to access its functions/methods
    $data = new LoginServer();
    
    // Variable to store messages
    $message = "";
    
    // Check if the registration form is submitted
    if (isset($_POST["signup"])) {
        // Retrieve and sanitize user input
        $username = $_POST["username"];
        $password = $_POST["password"];
        // Add more fields as needed
        
        // Perform user registration logic here
        // For example, you can use the LoginServer class to validate and create a new user
        
        if ($data->validateRegistration($username, $password)) {
            // Registration successful
            $message = "Registration successful. You can now log in.";
        } else {
            // Registration failed
            $message = $data->error;
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./signupStyles.css" />
    <title>EPMS Sign Up</title>
</head>
<body>
    <div class="signup__container">
        <h1>MARWING FARM: Sign Up</h1>
        <?php
            // Display registration message
            if (isset($message)) {
                echo '<label class="text-info">' . $message . '</label>';
            }
        ?>
        <form action="" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <!-- Add more fields as needed -->
            <button type="submit" name="signup">Sign Up</button>
        </form>
        <p>Already have an account? <a href="index.php">Log in</a></p>
    </div>   
</body>
</html>
